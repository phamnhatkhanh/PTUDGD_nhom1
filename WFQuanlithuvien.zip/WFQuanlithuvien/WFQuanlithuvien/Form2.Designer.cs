﻿using System.Windows.Forms;

namespace WFQuanlithuvien
{
    partial class FMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.PictureBox ptbLogOut;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FMain));
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblName = new System.Windows.Forms.Label();
            this.lblNameOfUser = new System.Windows.Forms.Label();
            this.ptbStudent = new System.Windows.Forms.PictureBox();
            this.ptbIssuedBook = new System.Windows.Forms.PictureBox();
            this.ptbReturnBook = new System.Windows.Forms.PictureBox();
            this.ptbBook = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnBook = new System.Windows.Forms.Button();
            this.btnIssuedBook = new System.Windows.Forms.Button();
            this.btnReturnBook = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnStudent = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblStudent = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblBooks = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lblUsers = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.lblIssued = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            ptbLogOut = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(ptbLogOut)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbStudent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbIssuedBook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbReturnBook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbBook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // ptbLogOut
            // 
            ptbLogOut.BackgroundImage = global::WFQuanlithuvien.Properties.Resources.logout1;
            ptbLogOut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            ptbLogOut.ErrorImage = null;
            ptbLogOut.InitialImage = null;
            ptbLogOut.Location = new System.Drawing.Point(12, 543);
            ptbLogOut.Name = "ptbLogOut";
            ptbLogOut.Size = new System.Drawing.Size(60, 60);
            ptbLogOut.TabIndex = 2;
            ptbLogOut.TabStop = false;
            ptbLogOut.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.lblName);
            this.panel2.Controls.Add(this.lblNameOfUser);
            this.panel2.Controls.Add(ptbLogOut);
            this.panel2.Controls.Add(this.ptbStudent);
            this.panel2.Controls.Add(this.ptbIssuedBook);
            this.panel2.Controls.Add(this.ptbReturnBook);
            this.panel2.Controls.Add(this.ptbBook);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.btnBook);
            this.panel2.Controls.Add(this.btnIssuedBook);
            this.panel2.Controls.Add(this.btnReturnBook);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.btnStudent);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(217, 626);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Yu Gothic UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(19, 40);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(67, 25);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "Admin";
            // 
            // lblNameOfUser
            // 
            this.lblNameOfUser.AutoSize = true;
            this.lblNameOfUser.Font = new System.Drawing.Font("Yu Gothic", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameOfUser.Location = new System.Drawing.Point(18, 9);
            this.lblNameOfUser.Name = "lblNameOfUser";
            this.lblNameOfUser.Size = new System.Drawing.Size(179, 31);
            this.lblNameOfUser.TabIndex = 2;
            this.lblNameOfUser.Text = "Name Of User";
            this.lblNameOfUser.Click += new System.EventHandler(this.lblNameOfUser_Click);
            // 
            // ptbStudent
            // 
            this.ptbStudent.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptbStudent.BackgroundImage")));
            this.ptbStudent.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptbStudent.Location = new System.Drawing.Point(12, 465);
            this.ptbStudent.Name = "ptbStudent";
            this.ptbStudent.Size = new System.Drawing.Size(60, 60);
            this.ptbStudent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ptbStudent.TabIndex = 2;
            this.ptbStudent.TabStop = false;
            this.ptbStudent.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // ptbIssuedBook
            // 
            this.ptbIssuedBook.BackgroundImage = global::WFQuanlithuvien.Properties.Resources.book;
            this.ptbIssuedBook.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptbIssuedBook.Location = new System.Drawing.Point(12, 308);
            this.ptbIssuedBook.Name = "ptbIssuedBook";
            this.ptbIssuedBook.Size = new System.Drawing.Size(60, 60);
            this.ptbIssuedBook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ptbIssuedBook.TabIndex = 2;
            this.ptbIssuedBook.TabStop = false;
            this.ptbIssuedBook.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // ptbReturnBook
            // 
            this.ptbReturnBook.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptbReturnBook.BackgroundImage")));
            this.ptbReturnBook.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptbReturnBook.Location = new System.Drawing.Point(12, 388);
            this.ptbReturnBook.Name = "ptbReturnBook";
            this.ptbReturnBook.Size = new System.Drawing.Size(60, 60);
            this.ptbReturnBook.TabIndex = 2;
            this.ptbReturnBook.TabStop = false;
            this.ptbReturnBook.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // ptbBook
            // 
            this.ptbBook.BackgroundImage = global::WFQuanlithuvien.Properties.Resources.books;
            this.ptbBook.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptbBook.Location = new System.Drawing.Point(12, 233);
            this.ptbBook.Name = "ptbBook";
            this.ptbBook.Size = new System.Drawing.Size(60, 60);
            this.ptbBook.TabIndex = 2;
            this.ptbBook.TabStop = false;
            this.ptbBook.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(37, 68);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 144);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // btnBook
            // 
            this.btnBook.Location = new System.Drawing.Point(94, 252);
            this.btnBook.Name = "btnBook";
            this.btnBook.Size = new System.Drawing.Size(103, 41);
            this.btnBook.TabIndex = 1;
            this.btnBook.Text = "Book";
            this.btnBook.UseVisualStyleBackColor = true;
            // 
            // btnIssuedBook
            // 
            this.btnIssuedBook.Location = new System.Drawing.Point(94, 327);
            this.btnIssuedBook.Name = "btnIssuedBook";
            this.btnIssuedBook.Size = new System.Drawing.Size(103, 41);
            this.btnIssuedBook.TabIndex = 1;
            this.btnIssuedBook.Text = "Issued book";
            this.btnIssuedBook.UseVisualStyleBackColor = true;
            this.btnIssuedBook.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnReturnBook
            // 
            this.btnReturnBook.Location = new System.Drawing.Point(94, 407);
            this.btnReturnBook.Name = "btnReturnBook";
            this.btnReturnBook.Size = new System.Drawing.Size(103, 41);
            this.btnReturnBook.TabIndex = 1;
            this.btnReturnBook.Text = "Return book";
            this.btnReturnBook.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(94, 562);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 41);
            this.button1.TabIndex = 1;
            this.button1.Text = "Log out";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnStudent
            // 
            this.btnStudent.Location = new System.Drawing.Point(94, 484);
            this.btnStudent.Name = "btnStudent";
            this.btnStudent.Size = new System.Drawing.Size(103, 41);
            this.btnStudent.TabIndex = 1;
            this.btnStudent.Text = "Student";
            this.btnStudent.UseVisualStyleBackColor = true;
            this.btnStudent.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel5.Controls.Add(this.lblStudent);
            this.panel5.Controls.Add(this.panel10);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Location = new System.Drawing.Point(302, 350);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(249, 175);
            this.panel5.TabIndex = 1;
            // 
            // lblStudent
            // 
            this.lblStudent.AutoSize = true;
            this.lblStudent.Font = new System.Drawing.Font("Yu Gothic UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudent.Location = new System.Drawing.Point(11, 115);
            this.lblStudent.Name = "lblStudent";
            this.lblStudent.Size = new System.Drawing.Size(130, 25);
            this.lblStudent.TabIndex = 2;
            this.lblStudent.Text = "Total Students";
            this.lblStudent.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel10.Location = new System.Drawing.Point(162, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(96, 175);
            this.panel10.TabIndex = 2;
            // 
            // panel7
            // 
            this.panel7.Location = new System.Drawing.Point(162, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(86, 157);
            this.panel7.TabIndex = 2;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel6.Controls.Add(this.lblBooks);
            this.panel6.Controls.Add(this.panel1);
            this.panel6.Location = new System.Drawing.Point(311, 85);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(249, 175);
            this.panel6.TabIndex = 1;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // lblBooks
            // 
            this.lblBooks.AutoSize = true;
            this.lblBooks.Font = new System.Drawing.Font("Yu Gothic UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBooks.Location = new System.Drawing.Point(25, 123);
            this.lblBooks.Name = "lblBooks";
            this.lblBooks.Size = new System.Drawing.Size(107, 25);
            this.lblBooks.TabIndex = 2;
            this.lblBooks.Text = "Total Books";
            this.lblBooks.Click += new System.EventHandler(this.lblBooks_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(153, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(96, 175);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel8.Controls.Add(this.lblUsers);
            this.panel8.Controls.Add(this.panel3);
            this.panel8.Location = new System.Drawing.Point(668, 85);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(249, 175);
            this.panel8.TabIndex = 1;
            // 
            // lblUsers
            // 
            this.lblUsers.AutoSize = true;
            this.lblUsers.Font = new System.Drawing.Font("Yu Gothic UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsers.Location = new System.Drawing.Point(19, 123);
            this.lblUsers.Name = "lblUsers";
            this.lblUsers.Size = new System.Drawing.Size(103, 25);
            this.lblUsers.TabIndex = 2;
            this.lblUsers.Text = "Total Users";
            this.lblUsers.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel3.Location = new System.Drawing.Point(153, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(96, 175);
            this.panel3.TabIndex = 2;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel9.Controls.Add(this.lblIssued);
            this.panel9.Controls.Add(this.panel4);
            this.panel9.Location = new System.Drawing.Point(668, 350);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(249, 175);
            this.panel9.TabIndex = 1;
            // 
            // lblIssued
            // 
            this.lblIssued.AutoSize = true;
            this.lblIssued.Font = new System.Drawing.Font("Yu Gothic UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIssued.Location = new System.Drawing.Point(19, 115);
            this.lblIssued.Name = "lblIssued";
            this.lblIssued.Size = new System.Drawing.Size(110, 25);
            this.lblIssued.TabIndex = 3;
            this.lblIssued.Text = "Total Issued";
            this.lblIssued.Click += new System.EventHandler(this.label3_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel4.Location = new System.Drawing.Point(153, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(96, 175);
            this.panel4.TabIndex = 2;
            // 
            // FMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 614);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel2);
            this.Name = "FMain";
            this.Text = "Quản lí thư viện";
            this.Load += new System.EventHandler(this.FMain_Load);
            ((System.ComponentModel.ISupportInitialize)(ptbLogOut)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbStudent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbIssuedBook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbReturnBook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbBook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private Button btnStudent;
        private PictureBox pictureBox1;
        private Button btnBook;
        private Button btnIssuedBook;
        private Button btnReturnBook;
        private PictureBox ptbBook;
        private PictureBox ptbIssuedBook;
        private PictureBox ptbReturnBook;
        private Label lblName;
        private Label lblNameOfUser;
        private Panel panel10;
        private Panel panel7;
        private Panel panel1;
        private Panel panel3;
        private Panel panel4;
        private Label lblStudent;
        private Label lblBooks;
        private Label lblUsers;
        private Label lblIssued;
        private Button button1;
        private PictureBox ptbStudent;
    }
}