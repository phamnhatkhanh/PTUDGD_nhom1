﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFQuanlithuvien
{
    public partial class FquanLiThuVien : Form
    {
        string Username, Password;
        public FquanLiThuVien()
        {
            InitializeComponent();
        }

        private void FquanLiThuVien_Load(object sender, EventArgs e)
        {

        }
        
        private void btnLogin_Click(object sender, EventArgs e)
        {
            Username = txtbUsername.Text;
            Password = txtbPassword.Text;

            if(Username == "" && Password == "")
            {
                MessageBox.Show("Đăng nhập thành công!!");
                this.Hide();
                string user = txtbUsername.Text;
                FMain obj = new FMain(char.ToUpper(user[0])+user.Substring(1));
                obj.ShowDialog();
                this.Show();
                

                //dùng để ẩn form login
               /* FMain f = new FMain();
                this.Hide();
                f.ShowDialog();
                this.Show();*/
            }
            else
            {
                MessageBox.Show("Sai tài khoản hoặc mật khẩu!!" + "\nVui lòng nhập lại.");
            }

            
        }
    }
}
